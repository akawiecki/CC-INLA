# spatial-inla
Repository containing the data for the Hierarchical modelling using INLA tutorial on the Coding Club website
